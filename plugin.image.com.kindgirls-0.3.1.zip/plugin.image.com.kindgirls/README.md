plugin.image.com.kindgirls
==========================

View photos and videos from https://www.kindgirls.com on Kodi

## Authors

- MaX <mx.ph.42@gmail.com>
- fr33p0rt <fr33p0rt@protonmail.com>
- DaM <kontakt@dpisarczyk.pl>

## 3rd party assets

##### fanart.jpg (all photos)

Photo by RODRIGO AMATUZZI from Pexels

## License

GPL 2.0
